var annotated_dup =
[
    [ "colorData", "structcolor_data.html", "structcolor_data" ],
    [ "MD_TCS230", "class_m_d___t_c_s230.html", "class_m_d___t_c_s230" ],
    [ "sensorData", "structsensor_data.html", "structsensor_data" ]
];