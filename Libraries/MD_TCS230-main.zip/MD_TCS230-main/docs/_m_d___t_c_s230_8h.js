var _m_d___t_c_s230_8h =
[
    [ "sensorData", "structsensor_data.html", "structsensor_data" ],
    [ "colorData", "structcolor_data.html", "structcolor_data" ],
    [ "MD_TCS230", "class_m_d___t_c_s230.html", "class_m_d___t_c_s230" ],
    [ "ARRAY_SIZE", "_m_d___t_c_s230_8h.html#a6242a25f9d996f0cc4f4cdb911218b75", null ],
    [ "NO_PIN", "_m_d___t_c_s230_8h.html#a762dbd131e5a17b098ed61330b268fd7", null ],
    [ "RGB_SIZE", "_m_d___t_c_s230_8h.html#ae2b058695db15038090e30b86f357452", null ],
    [ "TCS230_FREQ_HI", "_m_d___t_c_s230_8h.html#aed4aa7cad67adf935a962817a9c4794f", null ],
    [ "TCS230_FREQ_LO", "_m_d___t_c_s230_8h.html#af58494665cc7f7e732156633a3be1364", null ],
    [ "TCS230_FREQ_MID", "_m_d___t_c_s230_8h.html#aa98a5f57d6c2e42a1394dbc1c2f0c045", null ],
    [ "TCS230_FREQ_OFF", "_m_d___t_c_s230_8h.html#a4d57d31b92b18b1796aa7b70979e3606", null ],
    [ "TCS230_RGB_B", "_m_d___t_c_s230_8h.html#a9cdd6ac302a1ce150aedb86b8ce419d2", null ],
    [ "TCS230_RGB_G", "_m_d___t_c_s230_8h.html#a9726e262b8e05d26eb2b4007c3723c45", null ],
    [ "TCS230_RGB_R", "_m_d___t_c_s230_8h.html#ac3935ee2d9e1bb88574d56b315f7429c", null ],
    [ "TCS230_RGB_X", "_m_d___t_c_s230_8h.html#abd5cf9a828f724cebc4c8187d841b455", null ]
];