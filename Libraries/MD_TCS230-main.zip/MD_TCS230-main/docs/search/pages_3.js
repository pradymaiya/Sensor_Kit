var searchData=
[
  ['supported_20hardware',['Supported Hardware',['../page_hardware.html',1,'index']]]
];
