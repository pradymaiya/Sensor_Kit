var indexSectionsWithContent =
{
  0: "abcdgmnrstuv~",
  1: "cms",
  2: "m",
  3: "abgmrs~",
  4: "nrtv",
  5: "ad",
  6: "acrsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

