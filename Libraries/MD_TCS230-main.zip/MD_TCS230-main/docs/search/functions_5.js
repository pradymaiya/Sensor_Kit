var searchData=
[
  ['setdarkcal',['setDarkCal',['../class_m_d___t_c_s230.html#ab9f6199eb47082f89e94fb1dcfca145c',1,'MD_TCS230']]],
  ['setenable',['setEnable',['../class_m_d___t_c_s230.html#a9e038b9cd84d1aca4a1fe4adf689fad3',1,'MD_TCS230']]],
  ['setfilter',['setFilter',['../class_m_d___t_c_s230.html#a5323e7d8e6fcacf5966163c27c95767b',1,'MD_TCS230']]],
  ['setfrequency',['setFrequency',['../class_m_d___t_c_s230.html#a50106bee42eb52bffa4a5b690c327f3a',1,'MD_TCS230']]],
  ['setsampling',['setSampling',['../class_m_d___t_c_s230.html#a466345be9c755bad004df694660e1ae6',1,'MD_TCS230']]],
  ['setwhitecal',['setWhiteCal',['../class_m_d___t_c_s230.html#ac76afdd0a83baefafb43fa8670460763',1,'MD_TCS230']]]
];
